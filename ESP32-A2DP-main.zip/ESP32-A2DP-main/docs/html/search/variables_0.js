var searchData=
[
  ['cb_213',['cb',['../structapp__msg__t.html#a178b4f47f5dec620dd55568a112bed5c',1,'app_msg_t']]]
];
